public interface Myinterfaceone
{
 public void Mymethod1();
}