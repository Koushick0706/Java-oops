public class Finaltest implements Myinterfacetwo
{
 public static void main(String[] args)
 {
    Myinterfacetwo obj = new Finaltest();
    obj.Mymethod1();
    obj.Mymethod2();
 }
 @Override
 public void Mymethod1()
 { 
  System.out.println("Hi, am Interface Number1");
 }
 @Override
 public void Mymethod2()
 {
  System.out.println("Hi, Am Interface Number2");
 }
}