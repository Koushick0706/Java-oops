public interface Myinterfacetwo extends Myinterfaceone
{
  public void Mymethod2();
}