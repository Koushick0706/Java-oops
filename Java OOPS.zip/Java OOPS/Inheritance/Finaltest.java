public class Finaltest extends ClassB
{
  public static void main(String[] args)
  {
    ClassB obj = new ClassB();
    obj.Subtraction();
    obj.Addition();
    obj.mymethod2();
  }
}