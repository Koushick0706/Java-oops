public class ClassA
{
  int a = 10;
  int b = 20;
  void Addition()
  {
   int c = a+b;
   System.out.println("The Addition is" + c);
  }

  void mymethod1()
  {
   System.out.println("The Addition Method is Completed");
  }
  void mymethod2()
  {
   System.out.println("Go to Class B!");
  }
}