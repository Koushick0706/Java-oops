public class Baseclass
{
 void mymethod1(int x)
 {
   System.out.println("Hi, My name is Koushick! and My age is : " + x);
 }
 void mymethod1(int x,String a)
 { 
  System.out.println("The Sum is : " + x + "and also " +  a);
 }
 void mymethod1(int x, String a, char c)
 {
  System.out.println(" The integer is : " + x + " and string is " + a + " and character is : " + c);
 }
}