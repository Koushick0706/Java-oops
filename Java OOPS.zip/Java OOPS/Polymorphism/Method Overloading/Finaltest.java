public class Finaltest extends Baseclass
{
 public static void main(String[] args)
 {
  Baseclass obj = new Baseclass();
  obj.mymethod1(10);
  obj.mymethod1(10,"Nerupu daww");
  obj.mymethod1(10,"Nerupudaww",'N');
 }
}