public class Superclass extends Baseclass
{
  void mymethod3()
  {
    System.out.println("The Base Class Got Completed and Got Accessed in Superclass");
  }
  
  void Superclass()
  {
   System.out.println("My name is Superclass");
  }
  void mymethod4()
  {
   System.out.println("Hi,Superclass Welcome to Method Overridding ");
  }
  void mymethod5()
  {
   System.out.println(" Super class Executed !");
  }
}