public class Baseclass
{
 void mymethod1()
 {
   System.out.println("My name is Base class");
 }
 void mymethod2()
 {
  System.out.println("Hi, Baseclass Welcome to Method Overridding");
 }
 void mymethod3()
 {
  System.out.println("The Base class Gets Completed ! ");
 }
}