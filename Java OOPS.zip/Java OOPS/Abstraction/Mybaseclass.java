//Abstraction

public abstract class Mybaseclass
{
  int age = 10;
  
  abstract void Google();

  void MyGoogle(int x)
  {
   System.out.println("Welcome to Google");
  }
}