public class Abstraction extends Myclass
{
  public static void main(String[] args)
  { 
     Myclass obj = new Abstraction();
     System.out.println("Welcome to Main Method!");
     obj.MyGoogle(10);
     obj.Google();
     obj.Googlesearch();
  }
}