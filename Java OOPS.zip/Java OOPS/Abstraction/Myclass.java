public class Myclass extends Mybaseclass
{
  @Override
  void Google()
  {
    System.out.println("Welcome to Google Search! , Search Something!");
  }

 void Googlesearch()
 {
  System.out.println("Apple Inc");
 }
}