/*----Encapsulation---*/

public class Encapsulation{

private String course;
private String tution;


public String GetCourse()
{
  return course;
}

public String GetTution()
{
  return tution;
}

public void setCourse(String coursename)
{
  course = coursename;
}
public void setTution(String Tutionname)
{
  tution = Tutionname;
}
}